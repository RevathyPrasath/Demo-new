export class Registration {
      
        public firstName: string;
        public lastName: string;
        public emailAddress: string;
        public userName: string;
        public password: string;
    
    
    }
    