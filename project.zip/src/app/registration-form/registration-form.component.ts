import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import{ Registration } from '../shared/model/registration';

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent{
  registration: any={};
  submitted=false;

  onSubmit() { this.submitted = true; }

}
